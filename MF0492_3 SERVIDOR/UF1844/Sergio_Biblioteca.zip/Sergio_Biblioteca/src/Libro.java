public class Libro extends Material {

    private String editorial;

    public void altaMaterial() {
    }

    public void bajaMaterial() {
    }

    public void cambioMaterial() {
    }
}
