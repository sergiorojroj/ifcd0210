public class profesor extends Persona {

    private Integer numEmpleado;

    public void llevarMaterial() {
    }

    public void dejarMaterial() {
    }
}
