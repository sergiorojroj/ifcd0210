public class Revista extends Material {

    public void altaMaterial() {
    }

    public void bajaMaterial() {
    }

    public void cambioMaterial() {
    }
}
