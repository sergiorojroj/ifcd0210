public class Prestamo {

    private String codigo;

    private String id;

    private String fechaSalida;

    private String fechaRegreso;

    public void cuota() {
    }
}
