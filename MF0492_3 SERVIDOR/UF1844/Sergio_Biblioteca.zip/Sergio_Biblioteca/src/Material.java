public class Material {

    private String tipoMaterial;

    private String codigo;

    private String autor;

    private String titulo;

    private Integer anio;

    private String estadoLibro;

    public void altaMaterial() {
    }

    public void bajaMaterial() {
    }

    public void cambioMaterial() {
    }
}
