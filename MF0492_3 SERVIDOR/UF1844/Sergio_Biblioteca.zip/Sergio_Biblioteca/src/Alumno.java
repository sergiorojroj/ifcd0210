public class Alumno extends Persona {

    private Integer matricula;

    public void llevarMaterial() {
    }

    public void dejarMaterial() {
    }
}
