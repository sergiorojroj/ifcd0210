public class Biblioteca {

    public void CargarMateriales() {
    }

    public void CargarPersonas() {
    }
}
