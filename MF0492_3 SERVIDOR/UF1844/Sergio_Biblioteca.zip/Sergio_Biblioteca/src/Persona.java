public class Persona {

    private String tipoPersona;

    private String nombre;

    private String apellido;

    private String correo;

    private Integer telefono;

    private Integer numeroLibros;

    private Double recargo;

    public void llevarMaterial() {
    }

    public void dejarMaterial() {
    }
}
